const urlCreate = "http://localhost:8080/addcars";
const urlRetrieve = "http://localhost:8080/viewcars";
const urlUpdate = "http://localhost:8080/editcars";
const urlDelete = "http://localhost:8080/deletecars";
const urlLogin = "http://localhost:8080/login";
const urlLogout = "http://localhost:8080/logout";