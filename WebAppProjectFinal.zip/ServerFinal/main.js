

const bodyParser = require("body-parser");
const cors = require("cors");
const express = require("express");


'use strict';
const fs = require('fs');

let loginfo = fs.readFileSync('login.json');
let usrs = JSON.parse(loginfo);
var logins = usrs;
var loggedin = false;
var sign = {};


let rawdata = fs.readFileSync('data.json');
let car = JSON.parse(rawdata);
var CarDealership = car;


// ExpressJS configuration
const port = 8080;
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(cors());

app.get("/viewcars", function (req, res) {

    res.json(CarDealership);
});

app.post("/addcars", function (req, res) {
    var success = false;

    if (req.body) {
        if (!CarDealership[ req.body.id ] && loggedin) {
            CarDealership[ req.body.id ] = {
                "id": req.body.id,
                "Make": req.body.Make,
                "Model": req.body.Model,
                "Price": req.body.Price,
                "Colour": req.body.Colour,
                "Year": req.body.Year};
            success = true;

            fs.writeFile('./data.json', JSON.stringify(CarDealership, null, 2), err => {
                if (err) {
                    console.log(err);
                }
            });
        }
        if (success) {
            res.send("Car successfully added!");

        } else {
            res.send("Failed adding car, make sure you are Logged in");
        }
    }
});

app.post("/deletecars", (req, res) => {
    var success = false;

    if (req.body && loggedin) {
        if (CarDealership[ req.body.id ]) {
            delete CarDealership[ req.body.id ];
            success = true;
        }
    }

    if (success) {
        res.send("Product successfully deleted!");
        const jsonString = JSON.stringify(CarDealership);
        fs.writeFileSync('./data.json', jsonString);
    } else {
        res.send("Fail deleting the Car, Make sure you are Logged In");
    }
});

app.post("/editcars", (req, res) => {
    var cars;
    var success = false;

    if (req.body && loggedin) {
        if (CarDealership[ req.body.id ]) {
            cars = {
                "id": req.body.id,
                "Make": req.body.Make,
                "Model": req.body.Model,
                "Price": req.body.Price,
                "Colour": req.body.Colour,
                "Year": req.body.Year};
            CarDealership[ req.body.id ] = cars;
            success = true;
            fs.writeFile('./data.json', JSON.stringify(CarDealership, null, 2), err => {
                if (err) {
                    console.log(err);
                }
            });

        }
    }

    if (success) {
        res.send("Car successfully updated!");
    } else {
        res.send("Fail updating the Car!, Make sure you are Logged in");
    }
});


app.post("/login", (req, res) => {
    var success = false;
    if (req.body) {
        if (!sign[ req.body.id ]) {
            sign = {
                "id": req.body.id,
                "user": req.body.user,
                "pass": req.body.pass
            };
            success = true;
            console.log(sign);
        }
        if (success) {
            for (i = 0; i < 4; i++) {
                if (sign.id === logins[i].id && sign.user === logins[i].user && sign.pass === logins[i].pass) {
                    res.send("Welcome " + logins[i].user);
                    loggedin = true;
                    break;
                }
            }
            if (!loggedin) {
                res.send("Invalid ID/Username/Password");
            }


        } else {
            res.send("Error!");
        }
    }
});

app.post("/logout", (req, res) => {
    if (req.body) {
        if (loggedin) {
            loggedin = false;
            res.send("Logged Out " + sign.user);
        } else {
            res.send("You need to be logged in first");
        }


    }
});



app.listen(port, function () {
    console.log(`Server listening on port ${port}!`);
});